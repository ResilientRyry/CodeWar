function addBinary(a,b) {
//User adds two numbers
var sum = a + b
//retuns sum
return sum.toString(2)
//turns return into string

}

//Implement a function that adds two numbers together and returns their sum in binary.
//The conversion can be done before, or after the addition.

//The binary number returned should be a string.
